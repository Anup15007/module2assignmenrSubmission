CREATE TABLE EMP (
	empno number(4) NOT NULL,
	ename varchar2(10),
	job varchar2(9),
	mgr number(4),
	hiredate date,
	sal number(7,2),
	comm number(7,2),
	deptno number(2)
	);