CREATE INDEX idx_emp_hiredate ON emp(hiredate);
