create table AccountDetails
	as select * from accountsmaster;