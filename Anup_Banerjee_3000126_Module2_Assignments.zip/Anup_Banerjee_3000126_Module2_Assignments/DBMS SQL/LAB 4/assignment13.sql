create table suppliers(
	suppid number(5) not null,
	sname varchar2(20) not null,
	addr1 varchar2(30),
	addr2 varchar2(30),
	contactno number(10)
);