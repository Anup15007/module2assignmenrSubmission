insert into customermaster
	values (6003, 'John', '#114 Chicago', '#114 Chicago', 'M', 45, 439525, 19000.60);