select staff_name
	from staff_master
		where staff_name LIKE '%\_%' ESCAPE '\';
		
		
lINK-> https://docs.oracle.com/cd/B19306_01/server.102/b14200/conditions007.htm		