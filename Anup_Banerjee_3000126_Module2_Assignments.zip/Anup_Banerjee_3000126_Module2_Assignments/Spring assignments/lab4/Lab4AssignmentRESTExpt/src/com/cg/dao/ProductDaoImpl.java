package com.cg.dao;
import java.util.List;
import org.springframework.stereotype.Repository;
import com.cg.bean.Product;
import com.cg.staticdb.ProductDb;
@Repository
public class ProductDaoImpl implements IProductDao {

	@Override
	public List<Product> getAllProducts() {
		return ProductDb.getProductList();
	}

	@Override
	public void addProduct(Product product) {
		ProductDb.getProductList().add(product);
	}

	@Override
	public Product searchProduct(int id) {
		return ProductDb.getProductList().stream().
				filter(c->Integer.parseInt(c.getProdId())==id).findFirst().get();
	}

}
