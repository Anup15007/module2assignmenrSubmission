package com.cg.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.bean.Login;
import com.cg.bean.Trainee;

@Repository
@Transactional
public class TraineeDaoImpl implements TraineeDao {

	@PersistenceContext
	EntityManager entityManager = null;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public boolean isUserExixts(String usn) {

		Login usr = entityManager.find(Login.class, usn);

		if(usr!=null) {

			return true;
		}
		else {
			return false;
		}		
	}

	@Override
	public Login validateUser(Login login) {
		
		Login usr = entityManager.find(Login.class, login.getUserName());
		
		return usr;
	}

	@Override
	public Trainee insertTraineeDetails(Trainee trainee) {
		
		Login loginObj = new Login();
		
		//loginObj.setUserName(trainee.get);
		
		return null;
	}

	@Override
	public ArrayList<Trainee> getTraineeDetails() {
		return null;
	}

	@Override
	public Trainee deleteTrainee(String usn) {
		return null;
	}

}
